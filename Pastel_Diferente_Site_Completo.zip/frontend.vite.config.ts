import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({root:'frontend-src',base:'./',publicDir:'../public',plugins:[react()],build:{outDir:'../html-css-js',emptyOutDir:true,rollupOptions:{output:{entryFileNames:'js/painel.js',chunkFileNames:'js/[name]-[hash].js',assetFileNames:asset=>asset.names?.some(n=>n.endsWith('.css'))?'css/estilo.css':'assets/[name]-[hash][extname]'}}}});
