import {env} from 'cloudflare:workers';
import {initialState} from './domain.js';
export const db=()=>{const d=(env as any).DB;if(!d)throw new Error('Banco de dados indisponível.');return d;};
export const json=(value:any,status=200,headers:Record<string,string>={})=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
export async function sha(value:string){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));return Array.from(new Uint8Array(b)).map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function passwordHash(password:string,salt:string){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:100000,hash:'SHA-256'},key,256);return Array.from(new Uint8Array(b)).map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function readBody(req:Request){if(!req.headers.get('content-type')?.includes('application/json'))throw new Error('Formato inválido.');const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)throw new Error('Origem inválida.');const body=await req.text();if(body.length>100000)throw new Error('Requisição muito grande.');return JSON.parse(body);}
export async function session(req:Request){const raw=req.headers.get('cookie')?.match(/(?:^|;\s*)pd_session=([^;]+)/)?.[1];if(!raw)return null;const token=await sha(raw);const s=await db().prepare('SELECT token FROM sessions WHERE token=? AND expires>?').bind(token,Date.now()).first();return s?token:null;}
export async function getState(){
 await db().prepare('INSERT OR IGNORE INTO state (id,version,body) VALUES (1,0,?)').bind(JSON.stringify(initialState())).run();
 const result=await db().batch([db().prepare('SELECT version,body FROM state WHERE id=1'),db().prepare('SELECT kind,body FROM ledger ORDER BY rowid DESC')]);
 const row=result[0].results[0];const state=JSON.parse(row.body);delete state._writeToken;
 for(const k of ['sales','entries','movements','audit','requests'])state[k]=[];
 for(const record of result[1].results){state[record.kind].push(JSON.parse(record.body));}
 state.sales.sort((a:any,b:any)=>b.number-a.number);return {version:row.version,state};
}
export async function persistState(state:any,before:any,version:number){
 const token=crypto.randomUUID();const root={...state,_writeToken:token};
 const queries:any[]=[];
 for(const kind of ['sales','entries','movements','audit','requests']){
   root[kind]=[];const old=new Map(before[kind].map((r:any)=>[kind==='requests'?r:r.id,JSON.stringify(r)]));
   for(const record of state[kind]){const id=kind==='requests'?record:record.id;const body=JSON.stringify(record);if(old.get(id)===body)continue;
     queries.push(db().prepare("INSERT INTO ledger (id,kind,body) SELECT ?,?,? WHERE EXISTS (SELECT 1 FROM state WHERE id=1 AND json_extract(body,'$._writeToken')=?) ON CONFLICT(id) DO UPDATE SET body=excluded.body").bind(kind+':'+id,kind,body,token));
   }
 }
 const result=await db().batch([db().prepare('UPDATE state SET body=?,version=version+1 WHERE id=1 AND version=?').bind(JSON.stringify(root),version),...queries]);return result[0].meta.changes>0;
}
export async function getAdmin(){let a=await db().prepare('SELECT salt,hash FROM admin WHERE id=1').first();if(!a){const e=env as any;if(!e.ADMIN_HASH||!e.ADMIN_SALT)throw new Error('Acesso ainda não configurado.');await db().prepare('INSERT OR IGNORE INTO admin (id,salt,hash) VALUES (1,?,?)').bind(e.ADMIN_SALT,e.ADMIN_HASH).run();a=await db().prepare('SELECT salt,hash FROM admin WHERE id=1').first();}return a;}
export function constantEqual(a:string,b:string){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;}
export const cookie=(req:Request,value:string,age:number)=>`pd_session=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${new URL(req.url).protocol==='https:'?'; Secure':''}`;
