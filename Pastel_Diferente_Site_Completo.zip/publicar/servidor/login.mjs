import { db, json, readBody, getAdmin, passwordHash, constantEqual, sha, cookie } from './server.mjs';
export async function POST(req) { try {
    const b = await readBody(req);
    if (typeof b.password !== 'string' || b.password.length > 200)
        return json({ error: 'Usuário ou senha inválidos.' }, 401);
    const key = 'admin';
    const now = Date.now();
    await db().prepare('DELETE FROM attempts WHERE expires<?').bind(now).run();
    const attempt = await db().prepare('SELECT count FROM attempts WHERE id=?').bind(key).first();
    if (attempt?.count >= 10)
        return json({ error: 'Muitas tentativas. Aguarde 15 minutos.' }, 429);
    await db().prepare('INSERT INTO attempts (id,count,expires) VALUES (?,1,?) ON CONFLICT(id) DO UPDATE SET count=count+1').bind(key, now + 900000).run();
    const a = await getAdmin();
    const h = await passwordHash(b.password, a.salt);
    if (b.username !== 'admin' || !constantEqual(h, a.hash))
        return json({ error: 'Usuário ou senha inválidos.' }, 401);
    await db().prepare('DELETE FROM attempts WHERE id=?').bind(key).run();
    await db().prepare('DELETE FROM sessions WHERE expires<?').bind(now).run();
    const token = crypto.randomUUID() + crypto.randomUUID();
    await db().prepare('INSERT INTO sessions (token,expires) VALUES (?,?)').bind(await sha(token), now + 43200000).run();
    return json({ ok: true }, 200, { 'Set-Cookie': cookie(req, token, 43200) });
}
catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Não foi possível entrar.' }, 400);
} }
