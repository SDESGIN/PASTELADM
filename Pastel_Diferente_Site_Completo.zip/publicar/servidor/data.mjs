import { json, session, getState } from './server.mjs';
export async function GET(req) { try {
    if (!await session(req))
        return json({ error: 'Entre para acessar o painel.' }, 401);
    return json(await getState());
}
catch {
    return json({ error: 'Não foi possível carregar os dados. Tente novamente.' }, 503);
} }
