import { json, session, readBody, getState, persistState } from './server.mjs';
import { applyAction } from './domain.js';
export async function POST(req) { try {
    if (!await session(req))
        return json({ error: 'Sessão expirada. Entre novamente.' }, 401);
    const { action, requestId } = await readBody(req);
    if (typeof requestId !== 'string' || requestId.length > 100)
        return json({ error: 'Identificador inválido.' }, 400);
    for (let i = 0; i < 5; i++) {
        const { state, version } = await getState();
        const before = structuredClone(state);
        const result = applyAction(state, action, requestId);
        if (result.duplicate)
            return json({ state, version });
        if (await persistState(state, before, version))
            return json({ state, version: version + 1 });
    }
    return json({ error: 'Outro lançamento foi salvo agora. Tente novamente.' }, 409);
}
catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Não foi possível salvar.' }, 400);
} }
