import { db, json, session, readBody, cookie } from './server.mjs';
export async function POST(req) { try {
    await readBody(req);
    const token = await session(req);
    if (token)
        await db().prepare('DELETE FROM sessions WHERE token=?').bind(token).run();
    return json({ ok: true }, 200, { 'Set-Cookie': cookie(req, '', 0) });
}
catch {
    return json({ error: 'Não foi possível sair.' }, 400);
} }
