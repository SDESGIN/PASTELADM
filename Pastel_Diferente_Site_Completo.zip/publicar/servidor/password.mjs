import { db, json, session, readBody, getAdmin, passwordHash, constantEqual, cookie } from './server.mjs';
export async function POST(req) { try {
    if (!await session(req))
        return json({ error: 'Entre novamente.' }, 401);
    const b = await readBody(req);
    if (typeof b.current !== 'string' || typeof b.password !== 'string' || b.current.length > 200 || b.password.length < 10 || b.password.length > 200)
        return json({ error: 'Use uma nova senha de pelo menos 10 caracteres.' }, 400);
    const a = await getAdmin();
    if (!constantEqual(await passwordHash(b.current, a.salt), a.hash))
        return json({ error: 'Senha atual incorreta.' }, 400);
    const salt = crypto.randomUUID();
    const hash = await passwordHash(b.password, salt);
    await db().batch([db().prepare('UPDATE admin SET salt=?,hash=? WHERE id=1').bind(salt, hash), db().prepare('DELETE FROM sessions')]);
    return json({ ok: true }, 200, { 'Set-Cookie': cookie(req, '', 0) });
}
catch {
    return json({ error: 'Não foi possível alterar a senha.' }, 400);
} }
