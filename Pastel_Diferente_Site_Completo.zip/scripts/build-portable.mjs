import fs from 'node:fs';
import ts from 'typescript';
const out='publicar';fs.mkdirSync(out+'/servidor',{recursive:true});fs.cpSync('html-css-js',out+'/site',{recursive:true});fs.cpSync('drizzle',out+'/migrations',{recursive:true});
function compile(input,output){let s=fs.readFileSync(input,'utf8').replace("import {env} from 'cloudflare:workers';","import {env} from './ambiente.mjs';").replaceAll("'../../../lib/server'","'./server.mjs'").replaceAll("'../../../lib/domain.js'","'./domain.js'");fs.writeFileSync(out+'/servidor/'+output,ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText)}
compile('lib/server.ts','server.mjs');fs.copyFileSync('lib/domain.js',out+'/servidor/domain.js');for(const route of ['login','logout','action','data','password'])compile(`app/api/${route}/route.ts`,route+'.mjs');fs.cpSync('portable',out,{recursive:true});fs.writeFileSync(out+'/package.json',JSON.stringify({private:true,type:'module',scripts:{start:'node iniciar.mjs'},engines:{node:'>=22.13.0'}},null,2));
console.log('Pacote independente criado em publicar/');
