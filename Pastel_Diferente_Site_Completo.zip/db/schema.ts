import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const state=sqliteTable('state',{id:integer('id').primaryKey(),version:integer('version').notNull(),body:text('body').notNull()});
export const admin=sqliteTable('admin',{id:integer('id').primaryKey(),salt:text('salt').notNull(),hash:text('hash').notNull()});
export const sessions=sqliteTable('sessions',{token:text('token').primaryKey(),expires:integer('expires').notNull()});
export const attempts=sqliteTable('attempts',{id:text('id').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
export const ledger=sqliteTable('ledger',{id:text('id').primaryKey(),kind:text('kind').notNull(),body:text('body').notNull()});
