# Pastel Diferente — painel administrativo

Sistema de vendas, financeiro e estoque com uma conta administrativa. Identidade baseada na logo enviada, cardápio inicial com 41 variações (incluindo bases dos sucos) e sem lanche de pernil.

## O que está incluído

- Resumo por hoje, sete dias, mês, tudo ou intervalo personalizado.
- Venda com vários produtos, quantidades, observações, pagamento e troco.
- Confirmação de venda com total recalculado no servidor e identificador idempotente.
- Edição, cadastro, exclusão sem histórico ou desativação de produtos usados.
- Estoque por unidade ou receita; ingredientes em g, ml e un; entrada em kg/l convertida para a unidade base.
- Reposições, perdas, ajuste exato, estoque mínimo e compra vinculada a uma despesa.
- Entradas/saídas manuais, edição, cancelamento e categorias.
- Histórico de vendas, cancelamentos, estoque e alterações.
- Cancelamento financeiro com devolução de estoque opcional.
- Calculadora, exportação financeira CSV e cópia JSON de todos os dados.
- Senha com PBKDF2 SHA-256, salt individual, sessões HttpOnly, expiração em 12h, bloqueio temporário de tentativas e troca de senha.
- Banco D1 com registros individualizados e gravação transacional com controle de versão.

## Começar a usar

1. Abra o endereço do painel informado na conversa.
2. Entre com a conta administrativa entregue separadamente. As credenciais não ficam neste pacote.
3. Confira os produtos, especialmente o nome Sambarilov e o tamanho do açaí de R$ 20.
4. Cadastre os ingredientes e use Estoque → Movimentar para informar o estoque inicial real.
5. Configure as receitas nos produtos se quiser baixa automática de ingredientes. Por padrão, os produtos começam em controle manual.
6. Registre vendas e despesas. O saldo mostra entradas menos saídas, não lucro contábil.
7. Baixe cópias periódicas em Configurações. A cópia JSON é para arquivo/recuperação técnica; não há botão de importação. Não foi configurado agendamento externo de backup.

## Pastas e arquivos

- `html-css-js/index.html`: entrada HTML compilada.
- `html-css-js/css/estilo.css`: CSS compilado.
- `html-css-js/js/painel.js`: JavaScript compilado.
- `app/page.tsx`: interface editável em React/TypeScript.
- `app/globals.css`: estilos originais editáveis.
- `lib/domain.js`: regras de vendas, estoque e financeiro em JavaScript.
- `app/api/`: servidor de autenticação, leitura e gravação.
- `lib/server.ts`: persistência e autenticação.
- `db/schema.ts` e `drizzle/`: estrutura e migrações SQLite/D1.
- `frontend-src/` e `frontend.vite.config.ts`: geração alternativa do frontend HTML/CSS/JS.
- `tests/`: testes das regras e dos handlers com SQLite isolado.

## HTML e hospedagem

Este é um sistema com servidor e banco de dados. O HTML compilado deve ser servido por HTTP(S) junto das rotas `/api/*` implementadas neste projeto. Abrir apenas `index.html` com duplo clique ou publicar somente os arquivos estáticos NÃO habilita login nem gravação. Não existe senha escondida no JavaScript nem simulação de proteção via localStorage.

A publicação feita nesta conversa usa Sites e começa privada para a conta proprietária. Essa camada de hospedagem pode pedir login do ChatGPT antes do usuário/senha do painel. A dona da loja não terá acesso apenas com a senha se não tiver acesso à hospedagem privada. Para uma URL acessível por qualquer navegador somente com a senha administrativa, é necessário configurar uma hospedagem/audiência adequada separadamente. Nenhum dado foi tornado público.

## Ambiente de desenvolvimento

Requer Node 22.13+ e pnpm. Instale as dependências com `pnpm install --frozen-lockfile`.

- Desenvolvimento: `pnpm dev`.
- Compilação full-stack: `pnpm build`.
- Frontend HTML/CSS/JS: `pnpm exec vite build --config frontend.vite.config.ts`.
- Verificação TypeScript: `pnpm exec tsc --noEmit`.
- Regras: `node --test tests/domain.test.mjs`.
- API com SQLite isolado: `node --test tests/api.test.mjs`.

Configure `ADMIN_HASH` e `ADMIN_SALT` como segredos de runtime antes do primeiro acesso. O hash usa PBKDF2-HMAC-SHA256, 100.000 iterações, salt UTF-8 e 32 bytes em hexadecimal. O nome de usuário é `admin`. O primeiro login válido inicializa o registro; trocas posteriores ficam no banco. Não comite senha, `.dev.vars`, arquivos de ambiente, sessões ou dados reais.

Aplique as migrações SQL em ordem antes de usar as APIs. O projeto mantém a integração do starter Sites/Vinext para Workers e D1. Os fontes podem ser adaptados por um desenvolvedor para outra hospedagem compatível. As fontes DM Sans e Manrope usam Google Fonts, com fallback de sistema.

## Validação

As regras foram testadas para cálculo de totais, troco, preservação de preços antigos, receita, falta de estoque, idempotência, reposição com despesa e cancelamento. Os handlers foram testados com SQLite isolado para login, sessão, leitura persistente, transação, rejeição de edição concorrente, origem, senha e logout. A interface foi verificada em navegador com dados de teste isolados. Nenhum lançamento de teste é enviado ao banco de produção.

## Publicação independente — pacote pronto

A pasta `publicar/` contém o site compilado e servidor Node com SQLite, sem instalação de dependências. Não é necessário adaptar o código.

1. Use hospedagem com Node 22.13+ (preferencialmente 24), ou Docker, e disco persistente.
2. Envie todo o conteúdo de `publicar/`.
3. Configure `ADMIN_PASSWORD` com a senha inicial desejada (pelo menos 10 caracteres), `PUBLIC_ORIGIN` com sua URL HTTPS sem barra final e `DATABASE_PATH` com o arquivo no disco persistente. Exemplo: `/data/pastel.sqlite`.
4. Comando de início: `node iniciar.mjs`. Porta padrão: 3000; variável `PORT` aceita outra porta. A hospedagem deve encaminhar HTTPS para essa porta.
5. Login: `admin`. Após criar a conta, a senha fica no banco; mudanças em ADMIN_PASSWORD não substituem a senha já cadastrada. Troque a senha pelo painel.

Para teste local, configure ADMIN_PASSWORD no ambiente e execute `node iniciar.mjs` dentro de `publicar/`; abra http://localhost:3000. Para Docker, construa a imagem dentro da pasta e monte um volume persistente em `/data`. Não publique em hospedagem exclusivamente estática: login e gravação exigem este servidor.

O novo servidor inicia com um banco vazio e o cardápio cadastrado. Ele não copia automaticamente os dados da URL hospedada no ChatGPT. Preserve o disco do banco em atualizações. Para cópia integral, pare o servidor e copie todo o diretório de dados; o JSON exportado no painel continua disponível para consulta e recuperação técnica.
