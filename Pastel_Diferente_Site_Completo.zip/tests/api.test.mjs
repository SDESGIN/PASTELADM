import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import {pbkdf2Sync,randomUUID} from 'node:crypto';
import ts from 'typescript';
const dir=path.resolve('.sites-runtime/api-tests');fs.mkdirSync(dir,{recursive:true});
function compile(input,output){let s=fs.readFileSync(input,'utf8').replace("import {env} from 'cloudflare:workers';","const env=globalThis.__TEST_ENV;").replaceAll("'../../../lib/server'","'./server.mjs'").replaceAll("'../../../lib/domain.js'","'./domain.mjs'").replaceAll("'./domain.js'","'./domain.mjs'");fs.writeFileSync(path.join(dir,output),ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText);}
compile('lib/server.ts','server.mjs');fs.copyFileSync('lib/domain.js',path.join(dir,'domain.mjs'));for(const route of ['login','logout','action','data','password'])compile(`app/api/${route}/route.ts`,route+'.mjs');
const sql=new DatabaseSync(':memory:');for(const f of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sql.exec(fs.readFileSync('drizzle/'+f,'utf8'));
class Statement{constructor(q){this.q=q;this.args=[]}bind(...args){this.args=args;return this}async first(){return sql.prepare(this.q).get(...this.args)||null}async run(){const result=sql.prepare(this.q).run(...this.args);return {meta:{changes:Number(result.changes)}}}async all(){return {results:sql.prepare(this.q).all(...this.args)}}}
const DB={prepare:q=>new Statement(q),batch:async statements=>{sql.exec('BEGIN');try{const results=[];for(const s of statements)results.push(/^SELECT/i.test(s.q)?{results:sql.prepare(s.q).all(...s.args)}:{meta:{changes:Number(sql.prepare(s.q).run(...s.args).changes)}});sql.exec('COMMIT');return results}catch(e){sql.exec('ROLLBACK');throw e}}};
const password='test-'+randomUUID(),salt=randomUUID();globalThis.__TEST_ENV={DB,ADMIN_SALT:salt,ADMIN_HASH:pbkdf2Sync(password,salt,100000,32,'sha256').toString('hex')};
const routes={};for(const route of ['login','logout','action','data','password'])routes[route]=await import(path.join(dir,route+'.mjs'));
let cookie='';const call=async(route,body,headers={})=>{const req=new Request('https://test.local/api/'+route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json',Cookie:cookie,Origin:'https://test.local',...headers},body:body?JSON.stringify(body):undefined});return routes[route][body?'POST':'GET'](req)};
const action=async(a,id=randomUUID())=>{const r=await call('action',{action:a,requestId:id});const d=await r.json();assert.equal(r.status,200,JSON.stringify(d));return d};
test('API authentication, persistent ledger, idempotency, rollback, password and logout',async()=>{
 assert.equal((await call('data')).status,401);
 assert.equal((await call('login',{username:'admin',password:'wrong'})).status,401);
 const login=await call('login',{username:'admin',password});assert.equal(login.status,200);assert.match(login.headers.get('set-cookie'),/HttpOnly.*SameSite=Strict.*Secure/);cookie=login.headers.get('set-cookie').split(';')[0];
 let state=(await (await call('data')).json()).state;assert.equal(state.products.length,41);
 const id=randomUUID();const sale={type:'sale',items:[{id:'p1',qty:2,price:1000}],payment:'Dinheiro',received:5000};await action(sale,id);await action(sale,id);state=(await (await call('data')).json()).state;assert.equal(state.sales.length,1);assert.equal(state.sales[0].change,3000);
 await action({type:'cancelSale',id,reason:'Teste',returnStock:false});state=(await (await call('data')).json()).state;assert.equal(state.sales[0].cancelled,true);
 await action({type:'ingredient',name:'Farinha',unit:'g',min:50});state=(await (await call('data')).json()).state;const ingredient=state.ingredients[0];await action({type:'stock',kind:'ingredient',id:ingredient.id,operation:'add',qty:1000,expense:1200,reason:'Compra',payment:'Pix'});state=(await (await call('data')).json()).state;assert.equal(state.ingredients[0].stock,1000);assert.equal(state.entries[0].amount,1200);assert.equal(state.movements.length,1);
 const bad=await call('action',{action:{type:'stock',kind:'ingredient',id:ingredient.id,operation:'add',qty:50,expense:-1,reason:'Inválido'},requestId:randomUUID()});assert.equal(bad.status,400);state=(await (await call('data')).json()).state;assert.equal(state.ingredients[0].stock,1000);
 assert.equal((await call('action',{action:sale,requestId:randomUUID()},{Origin:'https://attacker.invalid'})).status,400);
 const server=await import(path.join(dir,'server.mjs'));const old=await server.getState();const other=structuredClone(old.state);other.products[0].name='Primeira edição';assert.equal(await server.persistState(other,old.state,old.version),true);const stale=structuredClone(old.state);stale.products[0].name='Edição perdida';stale.entries.push({id:'should-not-exist',amount:1});assert.equal(await server.persistState(stale,old.state,old.version),false);state=(await (await call('data')).json()).state;assert.equal(state.products[0].name,'Primeira edição');assert.equal(state.entries.some(e=>e.id==='should-not-exist'),false);
 assert.equal((await call('password',{current:'wrong',password:'New-test-password-123'})).status,400);assert.equal((await call('password',{current:password,password:'New-test-password-123'})).status,200);assert.equal((await call('data')).status,401);const login2=await call('login',{username:'admin',password:'New-test-password-123'});assert.equal(login2.status,200);cookie=login2.headers.get('set-cookie').split(';')[0];assert.equal((await call('logout',{})).status,200);assert.equal((await call('data')).status,401);
});
