import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Pastel Diferente · Gestão',description:'Vendas, financeiro e estoque da Pastel Diferente.',robots:{index:false,follow:false},icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
