import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,pbkdf2Sync} from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
const filename=process.env.DATABASE_PATH||path.join(root,'data','pastel.sqlite');fs.mkdirSync(path.dirname(filename),{recursive:true});
const sql=new DatabaseSync(filename);sql.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS portable_migrations (name TEXT PRIMARY KEY)');
for(const file of fs.readdirSync(path.join(root,'migrations')).filter(f=>f.endsWith('.sql')).sort()){if(sql.prepare('SELECT name FROM portable_migrations WHERE name=?').get(file))continue;sql.exec('BEGIN');try{sql.exec(fs.readFileSync(path.join(root,'migrations',file),'utf8'));sql.prepare('INSERT INTO portable_migrations VALUES (?)').run(file);sql.exec('COMMIT')}catch(e){sql.exec('ROLLBACK');throw e}}
class Statement{constructor(q){this.q=q;this.args=[]}bind(...args){this.args=args;return this}async first(){return sql.prepare(this.q).get(...this.args)||null}async run(){return {meta:{changes:Number(sql.prepare(this.q).run(...this.args).changes)}}}async all(){return {results:sql.prepare(this.q).all(...this.args)}}}
export const env={DB:{prepare:q=>new Statement(q),batch:async statements=>{sql.exec('BEGIN');try{const results=statements.map(s=>/^SELECT/i.test(s.q)?{results:sql.prepare(s.q).all(...s.args)}:{meta:{changes:Number(sql.prepare(s.q).run(...s.args).changes)}});sql.exec('COMMIT');return results}catch(e){sql.exec('ROLLBACK');throw e}}}};
if(!sql.prepare('SELECT id FROM admin WHERE id=1').get()){const password=process.env.ADMIN_PASSWORD;if(!password||password.length<10)throw new Error('Configure ADMIN_PASSWORD com pelo menos 10 caracteres antes de iniciar.');env.ADMIN_SALT=randomUUID();env.ADMIN_HASH=pbkdf2Sync(password,env.ADMIN_SALT,100000,32,'sha256').toString('hex')}
